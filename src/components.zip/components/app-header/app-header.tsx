import { FC } from 'react';
import { AppHeaderUI } from '@ui';

export const AppHeader: FC = () => <AppHeaderUI userName='' />;
