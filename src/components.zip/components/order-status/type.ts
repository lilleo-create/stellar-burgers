export type OrderStatusProps = {
  status: string;
};
