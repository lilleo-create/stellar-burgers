export type ConstructorPageUIProps = {
  isIngredientsLoading: boolean;
};
