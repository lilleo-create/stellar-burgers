export { FeedInfoUI } from './feed-info';
